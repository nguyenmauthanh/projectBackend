package com.a2m.service.role;

public interface RoleService {

}
