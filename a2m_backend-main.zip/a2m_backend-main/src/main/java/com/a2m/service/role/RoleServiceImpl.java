package com.a2m.service.role;

import org.springframework.stereotype.Service;

@Service
public class RoleServiceImpl implements RoleService{
	
}
